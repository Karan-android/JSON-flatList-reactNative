import React, { Component } from 'react';
import {
  AppRegistry, FlatList,
  StyleSheet, Text, View, Alert
} from 'react-native';
import { Appbar } from 'react-native-paper';
import AppBar from "@material-ui/core/AppBar"
import { Toolbar, Typography } from '@material-ui/core';



export default class App extends React.Component<{}, { data: Array<any> }> {
  constructor(props: {}) {
    super(props);
    this.state = { data: [] }

  }
  fetchData = async () => {
    const response = await fetch("https://randomuser.me/api/?results=100&inc=name", {
      method: 'GET',
      //Request Type
    }).then((data) => data.json()).then((jsonResponse: any) => {
      console.log(jsonResponse.results)
      this.setState({ data: jsonResponse.results })
    })

  };


  async componentDidMount() {
    this.fetchData()

  }
  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%",
          backgroundColor: "#000",
        }}
      />
    );
  };
  //handling onPress action  
  getListViewItem = (item: any) => {
    Alert.alert(item.key);
  }

  render() {
    console.log(this.state.data)
    return ( 
     
        <View style={styles.container}>
               <Appbar.Header>
                 <Text style={styles.text}>FLATLIST</Text>
    </Appbar.Header>
            <FlatList style={styles.flatlist}  
                data={this.state.data}  
                renderItem={({item}) => ( 
                    <Text style={styles.item}>
                      {item.name.title} {item.name.first} {item.name.last}
                      </Text>)}  
                ItemSeparatorComponent={this.renderSeparator}
                  
            />  
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: "0%",
  },
  flatlist:{
    padding:10,
    borderRadius:5
  },
  bottom: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  item: {
    padding: 10,
    fontSize: 18,
    height: 44
    
  },
  text:{
    fontSize:20,
    color:'#ffff',
    fontWeight:'500',
    paddingLeft:10
  }
})


